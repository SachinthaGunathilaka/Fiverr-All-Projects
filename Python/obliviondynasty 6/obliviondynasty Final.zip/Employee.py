class Employee:
    def __init__(self, name, employeeId, workingDepartment):
        self.name = name
        self.employeeId = employeeId
        self.workingDepartment = workingDepartment



