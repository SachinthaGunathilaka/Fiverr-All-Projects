public class Dog extends Pet {
    private String breed;

    public void setBreed(String userBreed) {
        breed = userBreed;
    }

    public String getBreed() {
        return breed;
    }


}