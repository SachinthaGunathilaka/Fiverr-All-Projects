* Install libraries
    pip install escpos
    pip install TikTokLive

* Set vendor ID and product ID

* Set the user ID of the live

* Run the file

