class Carriage:
    def __init__(self, tare, length):
        self.tare = tare
        self.length = length
        self.volume = 0
        self.type = ""


    def set_volume(self, volume):
        if volume > 0:
            self.volume = volume





