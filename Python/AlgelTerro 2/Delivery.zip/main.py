a b c = 1 000 000
print(abc)