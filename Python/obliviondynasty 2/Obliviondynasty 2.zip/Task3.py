filename = input()

file = open(filename)
lines = file.readlines()

tv_shows = []
flag = True

count = 0
name = ""
for line in lines:
    line = line.strip()

    if len(line) == 0:
        continue

    if flag:
        count = int(line)

    else:
        name = line
        tv_shows.append([name, count])

    flag = not flag

tv_shows.sort(key=lambda x: x[1])

for tv_show in tv_shows:
    print(tv_show[1])
    print(tv_show[0])
