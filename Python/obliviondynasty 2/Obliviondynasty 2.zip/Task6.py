def getStudentID():
    while True:
        student_id = input("Enter student id : ")

        is_valid = True
        for char in student_id:
            if not char.isalnum():
                is_valid = False
                print(f"Invalid student id.")
                break

        if is_valid:
            print(f"Valid student id.")
            return student_id


student_id = getStudentID()
print(student_id)
