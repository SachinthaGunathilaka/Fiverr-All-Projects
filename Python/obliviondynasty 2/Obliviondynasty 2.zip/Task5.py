def getName(username):
    username = username.strip()
    flag = True


    splitted_names = username.split()
    correct_name = ""

    for i in range(len(splitted_names)):
        if splitted_names[i] != splitted_names[i].capitalize():
            flag = False

        if i != len(splitted_names)-1:
            correct_name += splitted_names[i].capitalize() + " "

        else:
            correct_name += splitted_names[i].capitalize()

    if flag:
        return True, username

    else:
        return False, correct_name


# Testing

# Test Case 1
name1 = "Shane Watson"
is_valid, username = getName(name1)
if is_valid:
    print(f"{name1} is a valid username.")

else:
    print(f"{name1} is not a valid username. Is should be {username}.")

# Test Case 2
name2 = "Michael arnold"
is_valid, username = getName(name2)
if is_valid:
    print(f"{name2} is a valid username.")

else:
    print(f"{name2} is not a valid username. Is should be {username}.")

# Test Case 3
name3 = "mArry EMMa"
is_valid, username = getName(name3)
if is_valid:
    print(f"{name3} is a valid username.")

else:
    print(f"{name3} is not a valid username. Is should be {username}.")