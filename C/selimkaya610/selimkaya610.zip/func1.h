#ifndef _FUNC1_H
#define _FUNC1_H

// Import libraries
#include<stdlib.h>
#include<stdio.h>
#include<string.h>


// readFile method declaration
int *readFile(char *filename, int *size);

#endif