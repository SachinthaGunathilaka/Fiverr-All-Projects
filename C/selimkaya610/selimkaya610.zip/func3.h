#ifndef _FUNC3_H
#define _FUNC3_H

#include "func2.h"

// displayList method declaration
void displayList(struct Node * head);

#endif