#ifndef _FUNC4_H
#define _FUNC4_H

#include "func2.h"


// sortList method declaration
void sortList(struct Node *head, int size);

#endif