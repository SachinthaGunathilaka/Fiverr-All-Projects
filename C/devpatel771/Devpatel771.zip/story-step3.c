#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "rand_story.h"


int main(int argc, char *argv[]) {

    catarray_t *catarray = malloc(sizeof(*catarray));


    long cat_len, template_len;

    char *cat_buffer = readFile(argv[1], &cat_len);
    char *template_buffer = readFile(argv[2], &template_len);


    if (!cat_buffer) {
        printf("Categories file does not exists!\n");
        return -1;
    }

    if (!template_buffer) {
        printf("Story template file does not exists!\n");
        return -1;
    }

    int status = readCategories(cat_buffer, cat_len, catarray);

    if(status == -1){
        printf("Invalid format of the input file!\n");
        return -1;
    }

    char * result = readStoryTemplate(template_buffer, template_len, 2, catarray);

    if(strcmp(result, "format err") == 0){
        printf("No closing _ in the input file.\n");
        return -1;
    }

    if(strcmp(result, "null err") == 0){
        printf("Category does not exists.\n");
        return -1;
    }

    printf("%s\n", result);



    return 0;
}