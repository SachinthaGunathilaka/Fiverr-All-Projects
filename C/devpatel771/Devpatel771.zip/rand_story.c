#include "rand_story.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>


const char *chooseWord(char *category, catarray_t *cats) {
    if (cats == NULL)
        return "cat";

    for (int i = 0; i < cats->n; ++i) {
        if (strcmp(category, cats->arr[i].name) == 0) {
            return cats->arr[i].words[0];
        }
    }

    return "-1";
}


void addCategory(char *category, char *value, catarray_t *cats) {

    for (size_t i = 0; i < cats->n; i++) {
        if (strcmp(category, cats->arr[i].name) == 0) {
            cats->arr[i].n_words++;
            cats->arr[i].words = realloc(cats->arr[i].words, cats->arr[i].n_words * sizeof(*cats->arr[i].words));
            cats->arr[i].words[cats->arr[i].n_words - 1] = value;

            free(category);

            return;
        }
    }


    category_t temp_cat;
    temp_cat.name = category;
    temp_cat.n_words = 1;
    temp_cat.words = malloc(sizeof(temp_cat.words[0]));
    temp_cat.words[0] = value;

    cats->arr = realloc(cats->arr, (cats->n + 1) * sizeof(cats->arr[0]));
    cats->arr[cats->n] = temp_cat;
    cats->n++;

}

char *readFile(char *filename, long *length) {
    char *buffer = 0;

    FILE *f = fopen(filename, "rb");


    if (f) {

        fseek(f, 0, SEEK_END);
        *length = ftell(f);
        fseek(f, 0, SEEK_SET);
        buffer = malloc(*length);
        if (buffer) {
            fread(buffer, 1, *length, f);
        }
        fclose(f);
    } else {
        printf("Input file does not found!\n");
        return NULL;
    }

    return buffer;
}

int readCategories(char *buffer, long length, catarray_t *catarray) {
    int colons = 0, start = 0;
    char category[50], value[50];
    for (int i = 0; i < length; ++i) {
        if (buffer[i] == '\n' || i == length - 1) {
            if (colons == 0)
                continue;
            colons = 0;
            memset(value, 0, 50);
            if (i == length - 1)
                strncpy(value, buffer + start, i - start + 1);

            else
                strncpy(value, buffer + start, i - start);

            if (value[strlen(value) - 1] == '\n')
                value[strlen(value) - 1] = 0;


            char *temp_category = malloc(strlen(category));
            char *temp_value = malloc(strlen(value));

            strcpy(temp_category, category);
            strcpy(temp_value, value);

            addCategory(temp_category, temp_value, catarray);
            start = i + 1;


        }
        if (buffer[i] == ':') {
            memset(category, 0, 50);


            colons++;
            if (colons == 2) {
                return -1;
            }
            strncpy(category, buffer + start, i - start);


            start = i + 1;
        }
    }

    return 1;

}

char *readStoryTemplate(const char *buffer, long length, int option, catarray_t *catarray) {
    char * result = malloc(length + 500);
    category_t used_words;


    used_words.words = malloc(sizeof(used_words.words[0]));
    used_words.n_words = 1;

    int result_i = 0;
    int tag = 0;
    char word[30];
    int word_i = 0;
    for (int i = 0; i < length; ++i) {
        if (buffer[i] == '_') {
            if (tag) {
                tag = 0;
                word[word_i] = '\0';
                word_i = 0;

                const char *selected_word;
                if (option == 1) {
                    selected_word = chooseWord(word, catarray);
                } else {
                    int cat_number = atoi(word);
                    if (cat_number == 0) {
                        selected_word = chooseWord(word, catarray);
                        if (selected_word == NULL)
                            return "null err";

                        if(option == 3){
                            deleteValue(catarray, word, selected_word);
                        }
                    } else {
                        selected_word = used_words.words[used_words.n_words-1-cat_number];

                    }
                }

                char *temp_word = malloc(strlen(word));
                strcpy(temp_word, selected_word);

                used_words.words[used_words.n_words - 1] = temp_word;

                used_words.n_words++;
                used_words.words = realloc(used_words.words, used_words.n_words * sizeof(used_words.words[0]));

                strcat(result, selected_word);
                result_i += strlen(selected_word)-1;
            } else {
                tag = 1;
            }
        } else {
            if (tag) {
                word[word_i++] = buffer[i];
            } else {
                result[result_i++] = buffer[i];
            }
        }
    }
    if (tag) {
        return "format err";
    }

    return result;
}

void deleteValue(catarray_t * catarray, char * category, const char * value){
    for (int i = 0; i < catarray->n; ++i) {
        if(strcmp(catarray->arr[i].name, category) == 0) {
            int index = -1;
            for (int j = 0; j < catarray->arr[i].n_words; ++j) {
                if (strcmp(catarray->arr[i].words[j], value) == 0) {
                    index = j;
                }
            }

            if (index == -1)
                return;

            for (int j = index; j < catarray->arr[i].n_words - 1; ++j) {
                catarray->arr[i].words[j] = catarray->arr[i].words[j + 1];
            }
//            free(catarray->arr[i].words[catarray->arr[i].n_words-1]);
            catarray->arr[i].n_words--;

            break;

        }
    }
}