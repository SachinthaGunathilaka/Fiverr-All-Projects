#include <stdio.h>
#include <string.h>
#include "rand_story.h"

int main(int argc, char *argv[] ) {


    long length;

    char * buffer = readFile(argv[1], &length);

    if (buffer)
    {
        char * result = readStoryTemplate(buffer, length, 1, NULL);

        if(strcmp(result, "format err") == 0){
            printf("No closing _ in the input file.\n");
            return -1;
        }
        printf("%s\n", result);
    }
    return 0;
}