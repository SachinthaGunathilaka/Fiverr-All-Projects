
#include <stdio.h>
#include <stdlib.h>
#include "rand_story.h"

int main(int argc, char *argv[]) {

    catarray_t *catarray = malloc(sizeof(*catarray));

    long length;

    char *buffer = readFile(argv[1], &length);

    if (buffer) {

        int status = readCategories(buffer, length, catarray);

        if(status == -1){
            printf("Invalid format of the input file!\n");
            return -1;
        }

        printWords(catarray);
    }
    return 0;
}