#include "WaterPet.h"

WaterPet::WaterPet(string name, string color, double baseAdoptionFee, string water_type) : VirtualPet(name, color,
                                                                                                      baseAdoptionFee >=
                                                                                                      0
                                                                                                      ? baseAdoptionFee
                                                                                                      : 25) {
    if (water_type == "fresh" || water_type == "salt") {
        this->waterType = water_type;
    } else {
        this->waterType = "fresh";
    }
}

string WaterPet::getWaterType() {
    return waterType;
}


void WaterPet::printInfo() const {
    VirtualPet::printInfo();
    cout << "Water Type: " << waterType << endl;
};