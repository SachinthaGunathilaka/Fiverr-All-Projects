#ifndef RECTOOLS_H
#define RECTOOLS_H

// RecTools Header File
class RecTools {
public:
    // Function definitions
    int fact(int n);
    int fib(int x);
};


#endif
