//#include <iostream>
//#include "Unit.h"
//
//using namespace std;
//
//int main()
//{
//    Unit aUnit( "Data Structures and C++", "ICT283", 3 );
//    aUnit.SetCredits( 5 );
//    cout << aUnit << endl; // the operator << for Unit is called
//
//    //Test the Get Set for m_name
//    cout << aUnit.GetCredits() << endl;
//    aUnit.SetCredits(10);
//    cout << aUnit.GetCredits() << endl;
//
//    //Test the Get Set for m_unitID
//    cout << aUnit.GetMUnitID() << endl;
//    aUnit.SetMUnitID("ICT100");
//    cout << aUnit.GetMUnitID() << endl;
//    return 0;
//}
