//#include <iostream>
//
//#include "Result.h"
//#include "Unit.h"
//
//using namespace std;
//
//int main()
//{
//    Unit myUnit("Operating Systems", "ICT374", 4);
//    Result myResult(myUnit, 71);
//
//    cout << myResult << endl;
//
//    Unit anotherUnit("C Programming", "ICT159", 3);
//    myResult.SetUnit(anotherUnit);
//    myResult.SetMarks(69);
//
//    cout << myResult << endl;
//
//    return 0;
//}
