var searchData=
[
  ['remove_49',['Remove',['../class_vector.html#a8b48c7961e993156d29af165c000e792',1,'Vector']]],
  ['resize_50',['Resize',['../class_vector.html#a6bc28358cbde3afcd9a0d80fef0d8cfe',1,'Vector']]]
];
