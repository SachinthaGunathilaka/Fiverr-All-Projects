var searchData=
[
  ['time_134',['Time',['../class_time.html#a4245e409c7347d1d671858962c2ca3b5',1,'Time::Time()'],['../class_time.html#a2d9f66139c5140deccda5f09278244b4',1,'Time::Time(int hours, int minutes)']]]
];
