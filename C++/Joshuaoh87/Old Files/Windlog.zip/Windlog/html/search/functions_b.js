var searchData=
[
  ['windlogtype_136',['WindLogType',['../class_wind_log_type.html#a66ec93cd069c686f1a45e3fcd3c41769',1,'WindLogType::WindLogType()'],['../class_wind_log_type.html#aa3ad0453833139203c7361437c1cf96a',1,'WindLogType::WindLogType(Date &amp;date, Time &amp;time, float speed, float sr, float temp)']]]
];
