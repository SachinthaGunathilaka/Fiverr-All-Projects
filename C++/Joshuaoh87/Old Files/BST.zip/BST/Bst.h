#ifndef BST_H_INCLUDED
#define BST_H_INCLUDED
#include <iostream>

using namespace std;

template <class T>
struct Node
    {
        Node<T>* left;
        Node<T>* right;
        T m_data;

        T& GetData();
        Node<T>();
        Node<T> (const T &data);
    };

template <class T>
class Bst
{
private:
    typedef void(*InOrderPtr)(T &);
    typedef void(*PreOrderPtr)(T &);
    typedef void(*PostOrderPtr)(T &);

    Node<T>* root;
    Node<T>* InsertNode(Node<T>* node, const T &data);
    Node<T>* GetMinimumKey(Node<T>* node);          // helper function to find minimum value node in the subtree root at "node".
    Node<T>* DeleteNode(Node<T>* &root, const T &data);
    bool SearchNode(Node<T>* root, const T &data);
    void InOrder(Node<T>* root, void(*InOrderPtr)(T &)) const;
    void PreOrder(Node<T>* root, void(*InOrderPtr)(T &)) const;
    void PostOrder(Node<T>* root, void(*InOrderPtr)(T &)) const;
    void Destroy(Node<T>* &node);
    void DeleteFromTree(Node<T>* &node);
    void CopyTree(Node<T>* &copiedTreeRoot, Node<T>* otherTreeRoot);

public:
    Bst();
    ~Bst();
    const Bst<T>& operator=(const Bst<T>&);
    void Insert(const T &data);
    bool Search(const T &data);
    void Delete(const T &data);
    void DestroyTree();
    void InOrderTraversal(void (*InOrderPtr)(T&)) const;
    void PreOrderTraversal(void (*InOrderPtr)(T&)) const;
    void PostOrderTraversal(void (*InOrderPtr)(T&)) const;
    bool isEmpty() const;

};

// Node default constructor
template <class T>
Node<T>::Node()
{
    m_data = 0;
    left = nullptr;
    right = nullptr;
}

// Node parameterized constructor
template <class T>
Node<T>::Node(const T &data)
{
     this->m_data = data;
     left = nullptr;
     right = nullptr;
}

// Bst default constructor
template <class T>
Bst<T>::Bst()
{
    root = nullptr;
}

// destructor
template <class T>
Bst<T>::~Bst()
{
    Destroy(root);
}


template <class T>
void Bst<T>::CopyTree(Node<T>* &copiedTreeRoot, Node<T>* otherTreeRoot)
{
    if (otherTreeRoot == nullptr)
    {
        copiedTreeRoot = nullptr;
    }
    else
    {
        copiedTreeRoot = new Node<T>;
        copiedTreeRoot->m_data = otherTreeRoot->m_data;
        CopyTree(copiedTreeRoot->left, otherTreeRoot->left);
        CopyTree(copiedTreeRoot->right, otherTreeRoot->right);
    }
}

template <class T>
const Bst<T>& Bst<T>::operator=(const Bst<T>& otherTree)
{
    if (this!= &otherTree)      // avoid self copy
    {
        if (root != nullptr)    // if binary tree is not empty, destroy it.
        {
            Destroy(root);
        }
        if (otherTree.root == nullptr)
        {
            root = nullptr;
        }
        else
        {
            CopyTree(root, otherTree.root);
        }
    }
}

template <class T>
Node<T>* Bst<T>::InsertNode(Node<T>* node, const T &data)
{
    if (node == nullptr)
    {
        return new Node<T>(data);
    }
    else if (data < node->m_data)
    {
        node->left = InsertNode(node->left, data);
    }
    else if (data > node->m_data)
    {
        node->right = InsertNode(node->right, data);
    }
}

template <class T>
void Bst<T>::Insert(const T& data)
{
    root = InsertNode(root, data);
//    Node<T>* current;
//    Node<T>* trailCurrent = nullptr;
//    Node<T>* newNode;
//
//    newNode = new Node<T>;
//    newNode->m_data = data;
//    newNode->left = nullptr;
//    newNode->right = nullptr;
//
//    if(root == nullptr)
//    {
//        root = newNode;
//    }
//    else
//    {
//        current = root;
//
//        while (current != nullptr)
//        {
//            trailCurrent = current;
//
//            if (current->m_data == data)
//            {
//                cout << "The item inserted is already in the tree" << endl;
//                return;
//            }
//            else if(data < current->m_data)
//            {
//                current = current->left;
//            }
//            else
//            {
//                current = current->right;
//            }
//        }
//
//        if (trailCurrent->m_data > data)
//        {
//            trailCurrent->left = newNode;
//        }
//        else
//        {
//            trailCurrent->right = newNode;
//        }
//    }
}

template <class T>
bool Bst<T>::SearchNode(Node<T>* root,const T &data)
{
    if (root == nullptr)
    {
        return false;
    }

    if (root->m_data == data)
    {
    return true;
    }
    else if (data<root->m_data)
    {
      return SearchNode(root->left, data);
    }
    else if (data > root->m_data)
    {
      return SearchNode(root->right, data);
    }
}

template <class T>
bool Bst<T>::Search(const T &data)
{
    if(SearchNode(root, data))
    {
        return true;
    }
    else
    {
        return false;
    }
//    Node<T>* current;
//    bool found = false;
//
//    if(root == nullptr)
//    {
//        cout << "Cannot search an empty tree!" << endl;
//    }
//    else
//    {
//        current = root;
//
//        while (current != nullptr && !found)
//        {
//            if (current->m_data == data)
//            {
//                found = true;
//            }
//            else if (data < current->m_data)
//            {
//                current = current->left;
//            }
//            else
//            {
//                current = current->right;
//            }
//        }
//    }
//
//    return found;
}
template <class T>
void Bst<T>::DeleteFromTree(Node<T>* &node)
{
    Node<T>* current;       // pointer to traverse tree
    Node<T>* trailCurrent;  // pointer behind the current
    Node<T>* temp;          // pointer to delete the node

    if(node == nullptr)
    {
        cout << "Error: The node does not exist" << endl;
    }
    else if(node->left == nullptr && node->right == nullptr)
    {
        temp = node;
        node = nullptr;
        delete temp;
    }
    else if(node->left == nullptr)
    {
        temp = node;
        node = temp->right;
        delete temp;
    }
    else if(node->right == nullptr)
    {
        temp = node;
        node = temp->left;
        delete temp;
    }
    else
    {
        current = node->left;
        trailCurrent = nullptr;

        while (current->right != nullptr)
        {
            trailCurrent = current;
            current = current->right;
        }   // endwhile

        node->m_data = current->m_data;

        if (trailCurrent == nullptr)
        {
            node->left = current->left;
        }
        else
        {
            trailCurrent->right = current->left;
        }
        delete current;
    }
}

template <class T>
Node<T>* Bst<T>::GetMinimumKey(Node<T>* node)
{
    while (node->left != nullptr) {
    node = node->left;
    }
    return node;
}

template <class T>
Node<T>* Bst<T>::DeleteNode(Node<T>* &root, const T &data)
{
    if (root == nullptr)
    {
        return root;
    }
    else if(data < root->m_data)
    {
        root->left = DeleteNode(root->left,data);
    }
    else if(data > root->m_data)
    {
        root->right = DeleteNode(root->right,data);
    }
    else
    {
        if(root->left == nullptr && root->right == nullptr)
        {
            delete root;
            root = nullptr;
            return root;
        }
        else if(root->left == nullptr)
        {
            Node<T>* temp = root;
            root = root->right;
            delete temp;
            return root;
        }
        else if(root->right == nullptr)
        {
            Node<T>* temp = root;
            root = root->left;
            delete temp;
            return root;
        }

        Node<T>* temp = GetMinimumKey(root->right);

        root->m_data = temp->m_data;

        root->right = DeleteNode(root->right, temp->m_data);
    }
    return root;
}

template <class T>
void Bst<T>::Delete(const T &data)
{
    root = DeleteNode(root, data);
//    Node<T>* current;
//    Node<T>* trailCurrent;
//    bool found = false;
//
//    if (root == nullptr)
//    {
//        cout << "Cannot delete from a tree that is empty." << endl;
//    }
//    else
//    {
//        current = root;
//        trailCurrent = root;
//
//        while (current != nullptr && !found)
//        {
//            if (current->m_data == data)
//            {
//                found = true;
//            }
//            else
//            {
//                trailCurrent = current;
//                if (current->m_data > data)
//                {
//                    current = current->left;
//                }
//                else
//                {
//                    current = current->right;
//                }
//
//            }
//        }
//
//        if (current == nullptr)
//        {
//            cout << "There is no such data" << endl;
//        }
//        else if (found)
//        {
//            if (current == root)
//            {
//                DeleteFromTree(root);
//            }
//            else if (trailCurrent->m_data > data)
//            {
//                DeleteFromTree(trailCurrent->left);
//            }
//            else
//            {
//                DeleteFromTree(trailCurrent->right);
//            }
//        }
//        else
//        {
//            cout << "There is no such data" << endl;
//        }
//    }
}

template <class T>
void Bst<T>::Destroy(Node<T>* &node)
{
    if(node != nullptr)
    {
        Destroy(node->left);
        Destroy(node->right);
        delete node;
        node = nullptr;
    }
}

template <class T>
void Bst<T>::DestroyTree()
{
    Destroy(root);
}

template <class T>
void Bst<T>::InOrder(Node<T>* root, void(*InOrderPtr)(T &)) const
{
    if (root->left != nullptr)
    {
        InOrder(root->left, *InOrderPtr);
    }

    InOrderPtr(root->GetData());

    if (root->right != nullptr)
    {
        InOrder(root->right, *InOrderPtr);
    }
//    if (node != nullptr)
//    {
//        InOrder(node->left);
//        cout << node->m_data << " ";
//        InOrder(node->right);
//    }
}

template <class T>
void Bst<T>::PreOrder(Node<T>* root, void(*PreOrderPtr)(T &)) const
{
    PreOrderPtr(root->GetData());

    if (root->left != nullptr)
    {
        PreOrder(root->left, *PreOrderPtr);
    }

    if (root->right != nullptr)
    {
        PreOrder(root->right, *PreOrderPtr);
    }
//    if (node != nullptr)
//    {
//
//        cout << node->m_data << " ";
//        PreOrder(node->left);
//        PreOrder(node->right);
//    }
}

template <class T>
void Bst<T>::PostOrder(Node<T>* root, void(*PostOrderPtr)(T &)) const
{
    if (root->left != nullptr)
    {
        PostOrder(root->left, *PostOrderPtr);
    }

    if (root->right != nullptr)
    {
        PostOrder(root->right, *PostOrderPtr);
    }

    PostOrderPtr(root->GetData());
//    if (node != nullptr)
//    {
//        PostOrder(node->left);
//        PostOrder(node->right);
//        cout << node->m_data << " ";
//    }
}

template <class T>
void Bst<T>::InOrderTraversal(void (*InOrderPtr)(T&)) const
{
    InOrder(this->root, *InOrderPtr);
}

template <class T>
void Bst<T>::PreOrderTraversal(void (*PreOrderPtr)(T&)) const
{
    PreOrder(this->root, *PreOrderPtr);
}

template <class T>
void Bst<T>::PostOrderTraversal(void (*PostOrderPtr)(T&)) const
{
    PostOrder(this->root, *PostOrderPtr);
}

template <class T>
bool Bst<T>::isEmpty() const
{
    return (root == nullptr);
}

template <class T>
T& Node<T>::GetData()
{
    return this->m_data;
}


#endif // BST_H_INCLUDED
