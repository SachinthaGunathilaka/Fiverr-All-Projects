#ifndef NODE_H_INCLUDED
#define NODE_H_INCLUDED

using namespace std;

template <class N>
struct Node
{
    Node<N>* left;
    Node<N>* right;
    int m_data;
};



#endif // NODE_H_INCLUDED
