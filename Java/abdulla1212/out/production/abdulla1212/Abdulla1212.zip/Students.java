import java.io.*;
import java.util.Scanner;

public class Students {
    static String names[] = new String[20];
    static String ids[] = new String[20];
    static int exams[] = new int[20];
    static int assignments[] = new int[20];
    static int totals[] = new int[20];
    static int examsW = 40;
    static int assignsW = 60;
    static int regStudents;
    static int count = 20;


    public static void readData() {
        try {
            int index = 0;
            FileInputStream fis = new FileInputStream("data.in");
            Scanner sc = new Scanner(fis);
            while (sc.hasNextLine()) {
                if (index == 20)
                    break;
                String line = sc.nextLine();
                String[] data = line.split(" ");
                names[index] = data[0].strip();
                ids[index] = data[1].strip();
                assignments[index] = Integer.parseInt(data[2]);
                exams[index] = Integer.parseInt(data[3]);
                totals[index] = assignments[index] + exams[index];

                index++;
            }
            sc.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static void setValidName(int index) {
        boolean isValid = true;
        Scanner scanner = new Scanner(System.in);
        for (int i = 0; i < names[index].length(); i++) {
            if (!(Character.isAlphabetic(names[index].charAt(i)) || names[index].charAt(i) == '_')) {
                isValid = false;
                break;
            }
        }

        if (isValid)
            return;

        System.out.println("Invalid Name : " + names[index]);
        System.out.print("Enter Valid Name : ");
        names[index] = scanner.nextLine();
        setValidName(index);
    }

    public static void setValidID(int index) {
        boolean isValid = true;
        Scanner scanner = new Scanner(System.in);
        for (int i = 0; i < ids[index].length(); i++) {
            if (!Character.isDigit(ids[index].charAt(i))) {
                isValid = false;
                break;
            }
        }

        if (isValid)
            return;

        System.out.println("Invalid ID : " + ids[index]);
        System.out.print("Enter Valid ID : ");
        ids[index] = scanner.nextLine();
        setValidID(index);
    }

    public static void setValidMark(int index, char type) {
        boolean isValid = true;
        Scanner scanner = new Scanner(System.in);

        int max_weight = type == 'A' ? assignsW : examsW;
        int[] marks = type == 'A' ? assignments : exams;
        String text = type == 'A' ? "Assignment" : "Exam";


        if (marks[index] < 0 || marks[index] > max_weight) {
            System.out.println("Invalid " + text + " Mark (" + marks[index] + ") For " + names[index]);
            System.out.print("Enter Valid Mark : ");
            marks[index] = Integer.parseInt(scanner.nextLine());
            setValidMark(index, type);
        }

    }

    public static int getIndexByID(String id){
        for (int i = 0; i < count; i++) {
            if(ids[i].equals(id)){
                return i;
            }
        }

        return -1;
    }

    public static int getMaxIndex(char type){
        int [] marks = type == 'E' ? exams : type == 'A' ? assignments : totals;

        int maximum_mark = marks[0];
        int index = 0;
        for (int i = 1; i < count; i++) {
            if(maximum_mark < marks[i]){
                maximum_mark = marks[i];
                index = i;
            }
        }

        return index;
    }

    public static int getMinIndex(char type){
        int [] marks = type == 'E' ? exams : type == 'A' ? assignments : totals;

        int minimum_mark = marks[0];
        int index = 0;
        for (int i = 1; i < count; i++) {
            if(minimum_mark > marks[i]){
                minimum_mark = marks[i];
                index = i;
            }
        }

        return index;
    }

    public static double getAvg(char type){
        int [] marks = type == 'E' ? exams : type == 'A' ? assignments : totals;

        double sum = 0;
        for (int i = 0; i < count; i++) {
            sum += marks[i];
        }

        return sum / count;
    }

    public static void PrintDetailsByID(String id){
        int index = getIndexByID(id);
        System.out.printf("%s\t%-20s%5d%5d%5d\n", ids[index], names[index], assignments[index], exams[index], totals[index]);
    }

    public static void printDetails(){
        for (int index = 0; index < count; index++) {
            System.out.printf("%s\t%-20s%5d%5d%5d\n", ids[index], names[index], assignments[index], exams[index], totals[index]);
        }
    }

    public static displayMenu(){

    }


    public static void main(String[] args) {
        readData();
//
//
//        for (int i = 0; i < exams.length; i++) {
//            setValidMark(i, 'A');
//        }
//
//        for (int i = 0; i < exams.length; i++) {
//            System.out.println(assignments[i]);
//        }

//        System.out.println(getIndexByID("201203250"));

        System.out.println(getMaxIndex('A'));
        System.out.println(getMaxIndex('E'));
        System.out.println(getMaxIndex('T'));

        System.out.println(getMinIndex('A'));
        System.out.println(getMinIndex('E'));
        System.out.println(getMinIndex('T'));

        System.out.println(getAvg('A'));
        System.out.println(getAvg('E'));
        System.out.println(getAvg('T'));

        PrintDetailsByID("201201201");
        PrintDetailsByID("201205299");

        printDetails();

    }
}
