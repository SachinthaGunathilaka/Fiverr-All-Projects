package edu.upenn.cit594.datamanagement;

import java.sql.Timestamp;

public class CovidDataEntry {
    private Timestamp time;
    private int zipCode;
    private int negative;
    private int positive;
    private int deaths;
    private int hospitalized;
    private int partiallyVaccinated;
    private int fullyVacinated;
    private int boosted;


    public void setTime(Timestamp time) {
        this.time = time;
    }

    public Timestamp getTime() {
        return this.time;
    }

    public int getZipCode() {
        return zipCode;
    }

    public void setZipCode(int zipCode) {
        this.zipCode = zipCode;
    }

    public int getNegative() {
        return negative;
    }

    public void setNegative(int negative) {
        this.negative = negative;
    }

    public int getPositive() {
        return positive;
    }

    public void setPositive(int positive) {
        this.positive = positive;
    }

    public int getDeaths() {
        return deaths;
    }

    public void setDeaths(int deaths) {
        this.deaths = deaths;
    }

    public int getHospitalized() {
        return hospitalized;
    }

    public void setHospitalized(int hospitalized) {
        this.hospitalized = hospitalized;
    }

    public int getPartiallyVaccinated() {
        return partiallyVaccinated;
    }

    public void setPartiallyVaccinated(int partiallyVaccinated) {
        this.partiallyVaccinated = partiallyVaccinated;
    }

    public int getFullyVacinated() {
        return fullyVacinated;
    }

    public void setFullyVacinated(int fullyVacinated) {
        this.fullyVacinated = fullyVacinated;
    }

    public int getBoosted() {
        return boosted;
    }

    public void setBoosted(int boosted) {
        this.boosted = boosted;
    }
}


