package edu.upenn.cit594.processor;

import java.sql.Timestamp;
import java.util.List;
import java.util.Set;

import org.json.simple.JSONObject;

import edu.upenn.cit594.datamanagement.*;
import edu.upenn.cit594.ui.ScreenWriter;


public class CovidDataHandler {
	
	
	private String fileName;
	private CovidDataSet cdSet;
	
	public CovidDataHandler(String fileName) {
		this.fileName = fileName;
		cdSet = new CovidDataSet();
		
	}
	
	public void readData() {
		
		if(FileType.checkIfCsv(this.fileName)){
			handleFromCsv();
		}
		else if(FileType.checkIfJson(this.fileName)){
			handleFromJson();
		}
		else {
			ScreenWriter.DisplayErrorAndQuit("Wrong Type of File for Covid Data!");
		}
	}
	
	
	public void handleFromJson() {
		FileHandler fileHandler = new JsonHandler(fileName);
		
		
		List<Object> objArray = fileHandler.getFileAsList();//get a list of objects from the Json file
		
		

		//go through all objects in the array
		for(Object obj : objArray) {
			
			
			
			JSONObject jo = (JSONObject) obj;//convert the objects to JsonObjects
			Set<String> keySet = jo.keySet();//get the keys for the json object
			
			CovidDataEntry entry = new CovidDataEntry();
			
			if(keySet.contains("etl_timestamp")) {
				String time = (String) jo.get("etl_timestamp");
				entry.setTime(Timestamp.valueOf(time));
			}
			
			
			/*
			String text = (String)jo.get("text");
			
			JSONArray array = (JSONArray) jo.get("location");//array is an array of two doubles containing the latitude and longitude information
			
			Double latitude = (Double) array.get(0);
			Double longitude = (Double) array.get(1);
			*/
			
			
		}
	}
	
	public void handleFromCsv() {
		
	}
	
}
