package edu.upenn.cit594;

import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

//import edu.upenn.cit594.datamanagement.*;
import edu.upenn.cit594.datamanagement.DataHandler;
import edu.upenn.cit594.datamanagement.TxtHandler;
import edu.upenn.cit594.logging.Logger;
import edu.upenn.cit594.processor.*;
import edu.upenn.cit594.ui.ScreenWriter;
import edu.upenn.cit594.util.LoggerHelper;

public class Main {

    public static void main(String[] args) {

        // TODO Auto-generated method stub

        //get the logger instance
        Logger instance = Logger.getInstance();
        DataHandler dataHandler = DataHandler.getInstance();
        DataProcessor dataProcessor = DataProcessor.getInstance();

        String population_filename = "";
        String covid_filename = "";
        String properties_filename = "";
        String log_filename;

        Map<String, String> arguments = new HashMap<>();

        for (String arg : args) {
            Pattern pattern = Pattern.compile("^--(?<name>.+?)=(?<value>.+)$", Pattern.CASE_INSENSITIVE);
            Matcher matcher = pattern.matcher(arg);
            if (!matcher.find()) {
                ScreenWriter.DisplayErrorAndQuit("Argument do not match the form \"--name=value\"");
            }

            String name = arg.toLowerCase(Locale.ROOT).split("--")[1].split("=")[0];
            String value = arg.toLowerCase(Locale.ROOT).split("--")[1].split("=")[1];

            arguments.put(name, value);

        }

        dataHandler.validateArguments(arguments);

        if (args.length > 4) {
            ScreenWriter.DisplayErrorAndQuit("The name of an argument is use more than once");
        }

        TxtHandler populationHandler = new TxtHandler(dataHandler.getPopulation_filename());
        List<Object> population_lines = populationHandler.getFileAsList();

//        ScreenWriter.displayObjectList(population_lines);
        dataHandler.handlePopulation(population_lines);

        int option = 2;


        switch (option) {
            case 0:
                System.exit(0);
                break;
            case 1:
                List<String> dataset = dataProcessor.getAvailableDataSet();
                ScreenWriter.displayList(dataset);
                break;
            case 2:
                System.out.println(dataProcessor.getTotalPopulation());

        }
    }
}
