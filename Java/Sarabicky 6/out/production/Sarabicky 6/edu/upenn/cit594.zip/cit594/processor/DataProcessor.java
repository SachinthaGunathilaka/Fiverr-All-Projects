package edu.upenn.cit594.processor;

import edu.upenn.cit594.datamanagement.DataHandler;
import edu.upenn.cit594.ui.ScreenWriter;
import edu.upenn.cit594.util.Data;

import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class DataProcessor {


    private static DataProcessor dataProcessor = new DataProcessor();

    public static DataProcessor getInstance(){
        return dataProcessor;
    }

    public List<String> getAvailableDataSet(){
        List<String> dataset = new ArrayList<String>();

        DataHandler dataHandler = DataHandler.getInstance();

        if(dataHandler.getCovid_filename() != null){
            dataset.add("covid");
        }
        if(dataHandler.getPopulation_filename() != null){
            dataset.add("population");
        }
        if(dataHandler.getProperties_filename() != null){
            dataset.add("properties");
        }

        return dataset;
    }

    public int getTotalPopulation(){
        int total_population = 0;
        for (Map.Entry<String, Integer> entry : Data.getInstance().getPopulation().entrySet()) {
            total_population += entry.getValue();
        }

        return total_population;
    }
}
