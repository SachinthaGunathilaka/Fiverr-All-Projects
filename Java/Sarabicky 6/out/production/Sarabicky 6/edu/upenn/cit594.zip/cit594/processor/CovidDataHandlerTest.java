package edu.upenn.cit594.processor;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class CovidDataHandlerTest {

	@BeforeEach
	void setUp() throws Exception {
	}

	@Test
	void test() {
		CovidDataHandler cdHandler = new CovidDataHandler("covid_data.json");
		cdHandler.readData();
	}

}
