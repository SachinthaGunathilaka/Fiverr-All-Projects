package edu.upenn.cit594.util;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Data {
    private Map<String, Integer> population;

    private static Data data = new Data();

    public Data() {
        this.population = new HashMap<String, Integer>();
    }

    public void addPopulation(String zip, int count){
        this.population.put(zip, count);
    }

    public static Data getInstance() {
        return data;
    }

    public Map<String, Integer> getPopulation() {
        return population;
    }
}
