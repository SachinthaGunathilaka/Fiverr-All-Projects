package edu.upenn.cit594.ui;


import java.util.List;
import java.util.Map;

import edu.upenn.cit594.util.Format;

public class ScreenWriter {
	
	
	public static void DisplayErrorAndQuit(String error) {
		System.out.println(error);
		System.exit(0);
	}
	
	public static void displayString(String string) {
		System.out.println(string);
	}
	
	public static void displayMap(Map<String, Integer> map) {
		for(String key : map.keySet()) {
			System.out.println(Format.formatStateCountForPrint(key, map.get(key)));
		}
	}

	public static void displayList(List<String> list){
		for (String item:list) {
			System.out.println(item);
		}
	}

	public static void displayObjectList(List<Object> list){
		for (Object item:list) {
			System.out.println(item);
		}
	}

}
