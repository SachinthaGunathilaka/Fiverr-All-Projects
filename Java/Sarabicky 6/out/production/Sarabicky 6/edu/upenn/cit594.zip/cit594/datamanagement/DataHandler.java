package edu.upenn.cit594.datamanagement;

import edu.upenn.cit594.ui.ScreenWriter;
import edu.upenn.cit594.util.Data;

import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class DataHandler {


    private String population_filename = null;
    private String properties_filename = null;
    private String covid_filename = null;
    private String log_filename = null;

    private static DataHandler dataHandler = new DataHandler();

    public void validateArguments(Map<String, String> arguments) {

        for (Map.Entry<String, String> entry : arguments.entrySet()) {
            if (Objects.equals(entry.getKey(), "population")) {
                population_filename = entry.getValue();

                Path path = Paths.get(population_filename);
                if (Files.notExists(path)) {
                    ScreenWriter.DisplayErrorAndQuit(entry.getValue() + " File does not exists");
                }
            } else if (Objects.equals(entry.getKey(), "properties")) {
                properties_filename = entry.getValue();

                Path path = Paths.get(properties_filename);
                if (Files.notExists(path)) {
                    ScreenWriter.DisplayErrorAndQuit(entry.getValue() + " File does not exists");
                }
            } else if (Objects.equals(entry.getKey(), "covid")) {
                covid_filename = entry.getValue();

                if (!Objects.equals(covid_filename.split("\\.")[1], "json") && !Objects.equals(covid_filename.split("\\.")[1], "csv")) {
                    ScreenWriter.DisplayErrorAndQuit("The format of the covid data file can not be determined from the filename extension");
                }

                Path path = Paths.get(covid_filename);
                if (Files.notExists(path)) {
                    ScreenWriter.DisplayErrorAndQuit(entry.getValue() + " File does not exists");
                }
            } else if (Objects.equals(entry.getKey(), "log")) {
                log_filename = entry.getValue();

                Pattern pattern_filename = Pattern.compile("^[A-za-z0-9.]{1,255}$", Pattern.CASE_INSENSITIVE);
                Matcher matcher_filename = pattern_filename.matcher(log_filename);

                if (!matcher_filename.find()) {
                    ScreenWriter.DisplayErrorAndQuit("The logger cannot be correctly initialized");

                }
            } else {
                ScreenWriter.DisplayErrorAndQuit("Invalid name for the argument");
            }
        }

    }

    public static DataHandler getInstance() {
        return dataHandler;
    }

    public String getPopulation_filename() {
        return population_filename;
    }

    public String getProperties_filename() {
        return properties_filename;
    }

    public String getCovid_filename() {
        return covid_filename;
    }

    public String getLog_filename() {
        return log_filename;
    }

    public void handlePopulation(List<Object> population_lines) {
        int i = 0;
        for (Object line : population_lines) {
            if (i == 0) {
                i++;
                continue;

            }


            String zip = line.toString().split(",")[0];
            int count = Integer.parseInt(line.toString().split(",")[1]);
            Data.getInstance().addPopulation(zip, count);
        }
    }


}
