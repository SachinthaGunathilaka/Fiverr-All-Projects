package edu.upenn.cit594.datamanagement;

import java.util.ArrayList;
import java.util.List;

public class CovidDataSet {
	
	List<CovidDataEntry> list;
	
	public CovidDataSet() {
		list = new ArrayList<CovidDataEntry>();
	}
	
	public CovidDataSet(List<CovidDataEntry> list) {
		this.list = list;
	}
	
	public void addEntry(CovidDataEntry entry) {
		this.list.add(entry);
	}
}
