package edu.upenn.cit594.processor;

public interface AverageStratergy {
    public int calculateAverage(String zipcode);
}
