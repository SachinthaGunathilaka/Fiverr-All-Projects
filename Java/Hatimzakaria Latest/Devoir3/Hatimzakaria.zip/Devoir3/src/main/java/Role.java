public class Role {
    private String code;
    private String description;
}
