public class FormData {
    private String key;
    private String label;
    private DataType type;
    private String value;
    public String print(){
        return null;
    }
    public boolean validate(){
        return true;
    }
}
