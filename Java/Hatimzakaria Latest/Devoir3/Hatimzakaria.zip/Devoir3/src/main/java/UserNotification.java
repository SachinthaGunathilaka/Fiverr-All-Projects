public class UserNotification {
    private boolean read;
}
