public class AdminMenu extends Menu {
}
