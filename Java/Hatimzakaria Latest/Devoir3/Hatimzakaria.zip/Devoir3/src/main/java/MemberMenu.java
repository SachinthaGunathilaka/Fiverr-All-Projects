public class MemberMenu extends Menu{
}
