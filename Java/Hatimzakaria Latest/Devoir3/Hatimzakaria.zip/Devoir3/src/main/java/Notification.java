public class Notification {
    private String description;
    private String createDate;
}
