public enum ArticleStatus {
    DRAFT, READY, SUBMITTED, PUBLISHED, REJECTED
}
