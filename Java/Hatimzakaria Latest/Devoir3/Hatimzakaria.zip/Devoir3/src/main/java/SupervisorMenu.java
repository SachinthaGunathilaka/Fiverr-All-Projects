public class SupervisorMenu extends Menu {
}
