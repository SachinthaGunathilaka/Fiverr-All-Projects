public class Menu {
    private String context;
    public void home(){

    }
    public void print(String msg){

    }
    public void exit(){

    }
    public void back(){

    }
    public void clear(){

    }
    public void prompt(){

    }
    public void select(String option){

    }
    public void navigate (String option){

    }
    public void parse(String input){

    }

}
