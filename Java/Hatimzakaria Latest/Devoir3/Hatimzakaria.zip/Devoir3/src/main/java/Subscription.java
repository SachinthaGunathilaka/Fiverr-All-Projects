public class Subscription {
    private String subscribeDate;
}
