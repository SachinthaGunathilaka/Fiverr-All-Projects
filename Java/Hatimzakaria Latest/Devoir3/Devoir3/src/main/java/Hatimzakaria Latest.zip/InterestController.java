public class InterestController extends Controller{
    public Interest[] getInterest(FormData[] query){
        return null;
    }
    public Interest createInterest(Interest interest){
        return null;
    }
    public Interest updateInterest(Interest interest){
        return null;
    }
    public boolean deleteInterest(String id){
        return true;
    }
}
