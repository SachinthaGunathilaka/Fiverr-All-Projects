public enum DataType {;
    enum FormData {TEXT, NUMBER, DATE, ID, MULTITEXT};

}
