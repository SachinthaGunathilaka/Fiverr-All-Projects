public class NotificationService {
    private static NotificationService instance;
    public static NotificationService getInstance(){
        return null;
    }
    public boolean sendNotification(Notification notification, User[] user){
        return true;
    }
    public Notification createNotification(Activity activity){
        return null;
    }
}
