public class Form {
    private String name;
    private String action;
    public boolean validate(){
        return true;

    }
    public String print(){
        return null;

    }


}
