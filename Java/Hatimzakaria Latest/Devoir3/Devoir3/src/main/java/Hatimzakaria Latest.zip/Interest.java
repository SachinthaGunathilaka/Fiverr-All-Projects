import java.util.ArrayList;

public class Interest {
    private String id;
    private String name;
    private String description;

    private ArrayList<Member> members;
}
