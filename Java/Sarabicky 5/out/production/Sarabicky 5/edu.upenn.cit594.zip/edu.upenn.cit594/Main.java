package edu.upenn.cit594;

import edu.upenn.cit594.datamanagement.JsonParser;
import edu.upenn.cit594.datamanagement.Output;
import edu.upenn.cit594.datamanagement.StatesParser;
import edu.upenn.cit594.datamanagement.TextParser;
import edu.upenn.cit594.logging.Logger;
import edu.upenn.cit594.processor.TweetProcessor;
import edu.upenn.cit594.util.Data;

import java.util.Locale;
import java.util.Objects;

public class Main {
    public static void main(String[] args) {


        if (args.length != 3) {
            System.out.println("The number of arguments is incorrect.");
            return;
        }

        Data.data = new Data();


        try {
            if (Objects.equals(args[0].split("\\.")[1].toLowerCase(Locale.ROOT), "json")) {
                JsonParser jsonParser = new JsonParser(args[0]);
                if (!jsonParser.readJsonFile())
                    return;

            } else if (Objects.equals(args[0].split("\\.")[1].toLowerCase(Locale.ROOT), "txt")) {
                TextParser textParser = new TextParser(args[0]);
                if (!textParser.readTextFile())
                    return;
            } else {
                System.out.println("Invalid extension for tweets file.");
            }
        }catch (Exception e){
            System.out.println("Invalid extension for tweets file.");
            return;
        }


        StatesParser statesParser = new StatesParser(args[1]);
        if (!statesParser.readStatesFile())
            return;

        if(!Logger.getLogger().SetDestination(args[2]))
            return;

        TweetProcessor.filterTweets();

        TweetProcessor.categorizeTweets();
        Output.displayStateMap();


    }
}
