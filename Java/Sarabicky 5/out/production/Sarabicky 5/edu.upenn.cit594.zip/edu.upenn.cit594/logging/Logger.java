package edu.upenn.cit594.logging;

import java.io.FileWriter;
import java.io.PrintWriter;

public class Logger {
    public static Logger logger = new Logger();
    private String filename;

    public void log(String text){
        try {
            FileWriter fileWriter = new FileWriter(filename, true);
            PrintWriter printWriter = new PrintWriter(fileWriter);
            printWriter.println(text);
            printWriter.close();
        }catch (Exception e){
            System.out.println("Error occurred while logging");
        }

    }

    public boolean SetDestination(String filename){
        this.filename = filename;
        try {
            FileWriter fileWriter = new FileWriter(filename, true);
        }catch (Exception e){
            System.out.println("Cannot create/open the " + filename +" log file for writing");
            return false;
        }
        return true;
    }

    public static Logger getLogger(){
        return logger;
    }
}
