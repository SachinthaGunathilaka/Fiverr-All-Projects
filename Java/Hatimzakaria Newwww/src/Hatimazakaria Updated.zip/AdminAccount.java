public class AdminAccount extends Account{
    public AdminAccount(){

    }
}
