import re


def emailVerification():
    while True:
        email = input('Enter your email address: ')
        email_verify = r'\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b'
        if re.match(email_verify, email):
            save_data = ['\n', email]
            # Writing the data to login text file
            with open('authenticateFile.txt', 'a') as f:
                f.writelines(save_data)
            return True
        else:
            print('Invalid email type!')
            continue


def passwordValidCheck(password):
    special_sym = ['$', '@', '#', '%']
    val = True
    if len(password) < 8:
        print('length should be at least 8')
        val = False

    if not any(char.isdigit() for char in password):
        print('Password should have at least one numeral')
        val = False

    if not any(char.isupper() for char in password):
        print('Password should have at least one uppercase letter')
        val = False

    if not any(char.islower() for char in password):
        print('Password should have at least one lowercase letter')
        val = False

    if not any(char in special_sym for char in password):
        print('Password should have at least one of the symbols $@#%')
        val = False
    if val:
        return val


def passwordVerification():
    while True:
        password = input('Enter your password: (At least 8 characters, uppercase and lowercase, and one digit and one '
                         'special character)\n')
        if passwordValidCheck(password):
            print("Password is valid")
            reEnterPassword(password)
            save_data = [',', password]
            # Writing the data to login text file
            with open('authenticateFile.txt', 'a') as f:
                f.writelines(save_data)
            return True
        else:
            print("Invalid Password !!")
            continue


def reEnterPassword(password):
    while True:
        check_password = input('Enter your password again: \n')
        if check_password == password:
            print('Sign Up Successful!')
            return True
        else:
            print('Please enter same password!')
            continue


# Log In Function
def log_in():
    count = 0
    user_login = False
    student_list = []
    with open("authenticateFile.txt", 'r+') as text_file:
        for row in text_file:
            row = row.strip("\n")  # removing the newlines
            student_list.append(row.split(','))  # splitting the email & password from ','
    while count < 3:
        email = input('Enter your email address: ')
        new_password = input('Enter Password: ')
        for everything in student_list:
            email1 = everything[0]
            if email == email1:
                user_found = [everything[0], everything[1]]
                if user_found[1] == new_password:
                    user_login = True
                    break
                else:
                    continue
            else:
                continue
        if user_login:
            print('Sign In Successful!')
            break
        else:
            print('Wrong email or password!')
            count += 1
            if count == 3:
                exit()
            continue


print('Welcome')
print('************************************')
print('********Welcome to Akbar Park*******')
print('************************************')

while True:
    answer = input('Already signed up? [y/n]\n')
    if answer == 'y':
        print('*******Sign In*******')
        log_in()
        break
    elif answer == 'n':
        print('*******Sign Up*******')
        emailVerification()
        passwordVerification()
        break
    else:
        print('Please enter y or n!')
        continue

ticket_list = [[1, '11AM-1PM', 13.99, '4/4/2022'],
               [2, '1PM-3PM', 13.99, '4/4/2022'],
               [3, '3PM-5PM', 18.99, '4/4/2022'],
               [4, '5PM-7PM', 18.99, '4/4/2022'],
               [5, '11AM-1PM', 13.99, '4/5/2022'],
               [6, '1PM-3PM', 13.99, '4/5/2022'],
               [7, '3PM-5PM', 18.99, '4/5/2022'],
               [8, '5PM-7PM', 18.99, '4/5/2022']]

person_type = ''
ticket_count = 0
balance = 0
ticket_no = 0
cart_list = []

while True:
    discount = 0
    ride_fee = 0
    food_fee = 0
    menu = int(input('Choose an item [1-7].\n1- Buy a Ticket\n2- Reserve a Ride\n3- Buy Food\n4- Show the '
                     'Orders\n5- Check Out\n6- Clear the Cart\n7- Exit\n'))
    if menu == 1:
        '''Option 1-Buy Ticket'''
        f1 = open("tickets.txt", "r")
        print(f1.read())
        ticket_no = int(input('Select a Ticket from a list [1-8]\n'))
        person_type = input('Are you a student(s), an adult(a) ora kid(k)? [s/a/k]\n')
        ticket_count = int(input('How many tickets do you want?\n'))
        discount = 0
        ticket_price = ticket_list[ticket_no - 1][2] * ticket_count
        if person_type == 's':
            discount = ((ticket_list[ticket_no - 1][2] * 8) / 100) * ticket_count
        elif person_type == 'a':
            discount = 0
        elif person_type == 'k':
            discount = ((ticket_list[ticket_no - 1][2] * 9) / 100) * ticket_count

        ticket_charge = ticket_price - discount
        balance += ticket_charge
        print('The tickets have been added to your cart, your balance is $', "%.2f" % balance)
        add_ticket = [ticket_list[ticket_no - 1][1], '$', ticket_charge, ticket_list[ticket_no - 1][3]]
        cart_list.append(add_ticket)
        continue

    elif menu == 2:
        '''Option 2-Reserve a ride'''
        ride_fee = 0
        if ticket_count == 0:
            print('Please buy at least one ticket!')
            continue
        else:
            if person_type == 's':
                ride_fee = 20 * ticket_count
                name = 'student'
            elif person_type == 'a':
                ride_fee = 30 * ticket_count
                name = 'adult'
            elif person_type == 'k':
                ride_fee = 0
                name = 'kid'
            balance += ride_fee
            print('Your ride cost is $', '%.2f' % ride_fee, 'per ', name, ', for ',
                  ticket_list[ticket_no - 1][1])
            print('The ride reservations have been added to your cart, your balance is $', "%.2f" % balance)
            add_ride = ['A ride is reserved   $', ride_fee]
            cart_list.append(add_ride)
            continue

    elif menu == 3:
        '''Option 3-Buy Food'''
        if ticket_count == 0:
            print('Please buy at least one ticket!')
            continue
        else:
            f2 = open("Foodmenu.txt", "r")
            print(f2.read())
            food_request = input('What do you want to order? (type the menu item)\n')
            food_fee = 0
            if food_request == 'Taco':
                food_fee = 3.99
            elif food_request == 'Burritos':
                food_fee = 7.99
            elif food_request == 'Nachos':
                food_fee = 2.99
            elif food_request == 'Quesadilla':
                food_fee = 11.99
            elif food_request == 'Burger':
                food_fee = 5.99
            elif food_request == 'Cheeseburger':
                food_fee = 6.99
            else:
                print('Please enter valid food!')

            balance += food_fee
            print('A ', food_request, 'is added to your order')
            print('Your balance is $', '%.2f' % balance)
            add_food = [food_request, food_fee]
            cart_list.append(add_food)
            continue

    elif menu == 4:
        '''Option 4-Show Orders'''
        for i in cart_list:
            for j in i:
                print(j, end=' ')
            print('')
        continue

    elif menu == 5:
        '''Option 5-Checkout'''
        tax_rate = 0
        total_cost = 0
        for i in cart_list:
            for j in i:
                print(j, end=' ')
            print('')
        print('Your total cost before TAX is $', balance)
        state = input('Please enter your State [Texas, New-York, ....]\n')
        f3 = open('StateTaxRate.txt')
        for line in f3:
            line = line.rstrip()
            x = re.findall('^%s\S* ([0-9.]+)' % state, line)
            if len(x) > 0:
                tax_rate = float(x[0])

        total_cost = (balance * (100 + tax_rate)) / 100
        print('Your Tax rate is ', tax_rate)
        print('Your total cost after TAX is $', total_cost)
        card_no = input('Please enter your card number (16 digits)\n')
        if card_no.isdigit() and len(card_no) == 16:
            print('The transaction has been approved! Thank you.')
            continue
        else:
            print('Please enter valid credit card number!')
            continue

    elif menu == 6:
        '''Option 6-Empty Cart'''
        empty_cart = input('Are you sure? [y/n]')
        if empty_cart == 'y':
            cart_list.clear()
            print('Items from the cart have been removed!')
            continue
        else:
            continue

    elif menu == 7:
        '''Option 7-Exit'''
        print('Have a great day!, See you soon!')
        break

    else:
        print('Please enter number between 1 and 7!')
        continue
