import java.io.*;
import java.util.*;

public class Analyzer {

    public static List<Sentence> readFile(String filename) {

        List<Sentence> sentences = new ArrayList<Sentence>();
        {
            try {
                FileInputStream fis = new FileInputStream(filename);
                Scanner sc = new Scanner(fis);
                while (sc.hasNextLine()) {
                    String line = sc.nextLine();
                    String [] score_text = line.split("\\s", 2);

                    try {
                        int score = Integer.parseInt(score_text[0]);
                        if(score < -2 || score > 2)
                            continue;

                        Sentence sentence = new Sentence(score, score_text[1]);
                        sentences.add(sentence);


                    }catch (Exception e){
                        continue;
                    }


                }
                sc.close();
            } catch (Exception e) {
                return null;
            }

            return sentences;


        }
    }

        public static Set<Word> allWords (List < Sentence > sentences) {

            HashMap<String, Word> wordHashMap = new HashMap<String, Word>();

            if(sentences == null)
                return new HashSet<>(wordHashMap.values());


            for (Sentence s:sentences) {
                if(s == null || s.getText().length() == 0)
                    continue;
                String [] s_words = s.getText().toLowerCase().split(" ");

                for (String word:s_words) {
                    if(word.length() == 0 || !Character.isAlphabetic(word.charAt(0)))
                        continue;

                    Word temp;
                    if(wordHashMap.containsKey(word)){
                        temp = wordHashMap.get(word);
                    }
                    else{
                        temp = new Word(word);
                    }
                    temp.increaseTotal(s.getScore());
                    wordHashMap.put(word, temp);

                }
            }

            return new HashSet<>(wordHashMap.values());


        }

        public static Map<String, Double> calculateScores (Set < Word > words) {
            Map<String, Double> scores= new HashMap<String, Double>();

            for (Word word:words) {
                if(word == null)
                    continue;

                scores.put(word.getText(), word.calculateScore());
            }

            return scores;
        }

        public static double calculateSentenceScore (Map < String, Double > wordScores, String sentence){
            if(wordScores == null || wordScores.isEmpty())
                return 0;
            String [] words = sentence.split(" ");

            double score = 0;
            int count = 0;
            for (String word: words) {
                if(word.length() == 0)
                    continue;

                if(wordScores.containsKey(word)){
                    score += wordScores.get(word);
                }
                count++;
            }

            if(count != 0)
                return score/count;

            return 0;
        }

 
        public static void main (String[] args){
            if (args.length == 0) {
                System.out.println("Please specify the name of the input file");
                System.exit(0);
            }
            String filename = args[0];
            System.out.print("Please enter a sentence: ");
            Scanner in = new Scanner(System.in);
            String sentence = in.nextLine();
            in.close();
            List<Sentence> sentences = Analyzer.readFile(filename);


            Set<Word> words = Analyzer.allWords(sentences);

            Map<String, Double> wordScores = Analyzer.calculateScores(words);

            double score = Analyzer.calculateSentenceScore(wordScores, sentence);
            System.out.println("The sentiment score is " + score);
        }
    }
