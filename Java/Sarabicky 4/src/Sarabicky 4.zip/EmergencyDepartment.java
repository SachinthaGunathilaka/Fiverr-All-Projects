import java.util.Queue;

public class EmergencyDepartment {

    public Room [] rooms;
    public Doctor doctor;
    public Employee [] employees;
    public Queue<Patient> patients(){
        return null;
    }


}
