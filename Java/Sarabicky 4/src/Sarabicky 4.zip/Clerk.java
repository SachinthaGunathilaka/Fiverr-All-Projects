public class Clerk extends Employee{
    public boolean register(Patient patient){
        return false;
    }

    public boolean assign(Patient patient, Bed bed){
        return false;
    }
}
