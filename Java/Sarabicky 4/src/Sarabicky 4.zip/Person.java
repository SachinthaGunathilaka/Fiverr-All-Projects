import java.util.Date;

public class Person {
    public String name;
    public Date dob;
}
