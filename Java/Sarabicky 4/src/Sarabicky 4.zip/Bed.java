public class Bed {
    public String id;
    public Patient patient;
}
