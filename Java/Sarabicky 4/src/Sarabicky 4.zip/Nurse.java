public class Nurse extends Employee{
    public void beginShift(){
        return;
    }

    public void endShift(){
        return;
    }

    public boolean treat(Patient patient){
        return false;
    }
}
