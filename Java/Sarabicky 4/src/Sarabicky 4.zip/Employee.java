public abstract class Employee extends Person {
}
