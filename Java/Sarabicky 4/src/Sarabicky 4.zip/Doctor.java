public class Doctor extends Employee{
    public void discharge(Patient patient){
        return;
    }
}
