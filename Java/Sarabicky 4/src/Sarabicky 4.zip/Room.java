public class Room {
    public String number;
    public Bed [] beds;
}
