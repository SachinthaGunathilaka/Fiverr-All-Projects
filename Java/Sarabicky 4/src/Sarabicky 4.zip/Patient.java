import java.util.Date;

public class Patient extends Person {
    public String id;
    public Date arrivalDate;
    public Date dischargeDate;
    public String status;
}
